<?php
$name='ind_ta_1_001';
$type='TTF';
$desc=array (
  'Ascent' => 879,
  'Descent' => -488,
  'CapHeight' => 879,
  'Flags' => 4,
  'FontBBox' => '[-377 -370 2422 879]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 500,
);
$up=-188;
$ut=59;
$ttffile='G:/Blue Liquid Designs/4) BLUE LIQUID DESIGNS/12) FTP/2.2.0/mPDF/ttfonts/ind_ta_1_001.ttf';
$TTCfontID='0';
$originalsize=85328;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='ind_ta_1_001';
$panose=' 0 0 2 b 6 6 3 8 4 2 2 4';
$kerninfo=array (
);
$haskerninfo=true;
$unAGlyphs=false;
?>