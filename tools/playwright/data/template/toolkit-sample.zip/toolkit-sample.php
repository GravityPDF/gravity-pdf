<?php

/*
 * Template Name: Toolkit Sample
 * Version: 1.0
 * Description: Developer Toolkit template for end to end testing
 * Author: Gravity PDF
 * Author URI: https://gravitypdf.com
 * Group: Custom
 * Toolkit: true
 * Required PDF Version: 4.4.0
 */

/* Prevent direct access to the template */
if ( ! class_exists( 'GFForms' ) ) {
	return;
}

$w->writeHTML( '<h1>Toolkit Sample</h1>' );
