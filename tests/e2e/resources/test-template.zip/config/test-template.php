<?php

namespace GFPDF\Templates\Config;

use GFPDF\Helper\Helper_Interface_Config;

use GPDFAPI;

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Test_Template
 *
 * @package  GFPDF\Templates\Config
 *
 * @Internal See https://gravitypdf.com/documentation/v4/developer-template-configuration-and-image/ for more information about this class
 */
class Test_Template implements Helper_Interface_Config {

	/**
	 * Return the templates configuration structure which control what extra fields will be shown in the "Template" tab when configuring a form's PDF.
	 *
	 * @return array The array, split into core components and custom fields
	 *
	 * @since 1.0
	 */
	public function configuration() {
		return [
			/* Create custom fields to control the look and feel of a template */
			'fields' => [
				'my_text_field' => [
					'id'   => 'my_text_field',
					'name' => 'Label',
					'type' => 'text',
					'desc' => 'Description about this field',
				],
				'prefix_my_custom_rich_editor' => [
					'id'         => 'prefix_my_custom_rich_editor',
					'name'       => esc_html__( 'Rich Editor', 'gravity-forms-pdf-extended' ),
					'type'       => 'rich_editor',
					'size'       => 12, /* control the default height of the editor */
					'inputClass' => 'merge-tag-support mt-wp_editor mt-manual_position mt-position-right mt-hide_all_fields', /* enable merge tag support */
				],
				'prefix_my_custom_select' => [
					'id'      => 'prefix_my_custom_select',
					'name'    => esc_html__( 'Select', 'gravity-forms-pdf-extended' ),
					'type'    => 'select',
					'options' => [
						'Value 1' => 'Option 1',
						'Value 2' => 'Option 2',
						'Value 3' => 'Option 3',
						'Value 4' => 'Option 4',
					],
					'chosen'  => true, /* Enable advanced drop down selector */
				],
				'prefix_my_custom_checkbox' => [
					'id'     => 'prefix_my_custom_checkbox',
					'name'   => esc_html__( 'Checkbox', 'gravity-forms-pdf-extended' ),
					'type'   => 'checkbox',
					'desc'   =>  esc_html__( 'The checkbox label', 'gravity-forms-pdf-extended' ),
				],
				'prefix_my_custom_radio' => [
					'id'      => 'prefix_my_custom_radio',
					'name'    => 'Radio',
					'desc'    => 'This is my field description',
					'type'    => 'radio',
					'options' => [
						'Yes' => __( 'Yes', 'gravity-forms-pdf-extended' ),
						'No'  => __( 'No', 'gravity-forms-pdf-extended' ),
					],
					'std'     => 'No',
				]
			],
		];
	}
}
