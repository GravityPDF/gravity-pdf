<?php

/*
 * Template Name: Test Template
 * Version: 1.0
 * Description: Test template for end to end testing
 * Author: Gravity PDF
 * Author URI: https://gravitypdf.com
 * Group: Custom
 * Required PDF Version: 4.4.0
 */

/* Prevent direct access to the template */
if ( ! class_exists( 'GFForms' ) ) {
	return;
}

/**
 * All Gravity PDF v4/v5 templates have access to the following variables:
 *
 * @var array  $form      The current Gravity Form array
 * @var array  $entry     The raw entry data
 * @var array  $form_data The processed entry data stored in an array
 * @var array  $settings  The current PDF configuration
 * @var array  $fields    An array of Gravity Form fields which can be accessed with their ID number
 * @var array  $config    The initialised template config class – eg. /config/zadani.php
 * @var object $gfpdf     The main Gravity PDF object containing all our helper classes
 * @var array  $args      Contains an array of all variables - the ones being described right now - passed to the template
 */

?>

<!-- Include styles needed for the PDF -->
<style>

</style>

<!-- Output our HTML markup -->
